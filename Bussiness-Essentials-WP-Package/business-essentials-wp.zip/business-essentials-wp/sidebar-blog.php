<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('blog') ) : else : ?>		
<?php endif; ?>