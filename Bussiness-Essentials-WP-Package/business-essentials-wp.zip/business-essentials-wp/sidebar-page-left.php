<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('page-left') ) : else : ?>		
<?php endif; ?>