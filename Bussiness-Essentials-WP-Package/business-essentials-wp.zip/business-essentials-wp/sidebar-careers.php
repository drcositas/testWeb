<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('careers') ) : else : ?>		
<?php endif; ?>